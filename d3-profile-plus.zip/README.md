d3-profile-enhancer
===================

Chrome extension for exhancing d3 profiles. Adds elemental damage and elemental elite damage do the battle.net user profile.
